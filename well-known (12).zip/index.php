<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tổng quan</title>

</head>
<style>

</style>


<body>
  <?php
  require_once __DIR__ . '/header.php';
  $q = trim($_GET['q'] ?? '');
  $sql = "SELECT * FROM tours WHERE 1";
  $params = [];

  if ($q !== '') {
    $sql .= " AND (name LIKE ? OR destination LIKE ? OR tour_type LIKE ?)";
    $params = ["%$q%", "%$q%", "%$q%"];
  }
  if ($q !== '') {
    $sql .= " ORDER BY created_at DESC LIMIT 50";
  } else {
    $sql .= " ORDER BY created_at DESC";
  }

  $stmt = $pdo->prepare($sql);
  $stmt->execute($params);
  $tours = $stmt->fetchAll(PDO::FETCH_ASSOC);
  ?>

  <main class="main">
    <div class="section-1">
      <div class="container">
        <div class="inner-wrap">
          <h2 class="inner-title">BẠN LỰA CHỌN TOUR DU LỊCH NÀO ?</h2>
          <p class="inner-desc">Có rất nhiều tour du lịch giá tốt đang chờ bạn</p>
          <form class="row g-2" method="get">
            <div class="col-md-10">
              <input class="form-control form-control-lg" name="q" placeholder="Tìm theo tên, điểm đến, loại hình..."
                value="<?php echo h($q); ?>">
            </div>
            <div class="col-md-2 d-grid">
              <button class="btn btn-light btn-lg">Tìm kiếm</button>
            </div>
          </form>



        </div>
      </div>
    </div>
    <div class="section-2">
      <div class="container">
        <div class="inner-wrap">
          <div class="inner-title">
            <h2>

              <div class="bottom-row"><span></span>
                <p></p>
              </div>
            </h2>
          </div>
          <div class="inner-desc">
            <p></p>
          </div>
        </div>
      </div>
    </div>


    <div class="section-3">
      <div class="container">
        <h2 class="box-title">Các Tour Dành Cho Quý Khách </h2>
        <div class="inner-wrap">
          <?php if ($tours): ?>
            <?php foreach ($tours as $t): ?>

              <div class="product-item">
                <?php if (!empty($t['image_url'])): ?>
                  <div class="inner-image"><a href="#"><img src="<?php echo h($t['image_url']); ?>" alt=""></a></div>
                <?php else: ?>
                <?php endif; ?>
                <div class="inner-address"><i class="fa-solid fa-location-dot"></i>Đà Nẵng</div>
                <div class="inner-content">
                  <h3 class="inner-title"><?php echo h($t['name']); ?></h3>
                  <div class="inner-time"><i
                      class="fa-solid fa-clock-rotate-left"></i><?php echo h($t['duration_days']); ?>N</div>
                </div>
                <div class="inner-price-button">
                  <div class="inner-price"><?php echo money($t['price']); ?></div>
                  <div class="inner-button">
                    <button onclick="window.location.href='<?php echo asset_url('tour.php?id=' . (int) $t['id']); ?>'">
                      Đặt ngay
                    </button>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <div class="col-12">
              <div class="alert alert-info">Không tìm thấy tour phù hợp.</div>
            </div>
          <?php endif; ?>

        </div>
        <div class="inner-bottom">
          <div class="inner-button">
            <button>Xem tất cả tour du lịch<i class="fa-solid fa-arrow-right"></i></button>
          </div>
        </div>
      </div>
    </div>


    <div class="section-4">
      <div class="container">
        <div class="box-title">
          <h2>CÁC TOUR DU LỊCH NỔI BẬT CỦA CHÚNG TÔI</h2>
        </div>
        <div class="inner-wrap">
          <div class="blog-item"><a href="">
              <div class="inner-image"><img src="assets/images/homestay-da-lat.jpg" alt=""></div>
              <div class="inner-content">
                <div class="inner-date">23/05/2024</div>
                <h3 class="inner-title">Homestay “cổ tích” giữa Đà Lạt mộng mơ</h3>
              </div>
            </a>
          </div>




          <div class="blog-item"><a href="">
              <div class="inner-image"><img
                  src="https://s3.hcm-1.cloud.cmctelecom.vn/vtv-image/Images/Tour/tfd__1_10593_nui-phu-si1.webp" alt="">
              </div>
              <div class="inner-content">
                <div class="inner-date">23/05/2024</div>
                <h3 class="inner-title">Homestay “khu vườn” giữa Hà Nội mộng mơ</h3>
              </div>
            </a>
          </div>



          <div class="blog-item"><a href="#">
              <div class="inner-image"><img
                  src="https://s3.hcm-1.cloud.cmctelecom.vn/vtv-image/Images/Tour/tfd__0_11368_cape-town-africa.webp"
                  alt=""></div>
              <div class="inner-content">
                <div class="inner-date">23/05/2024</div>
                <h3 class="inner-title">Homestay “khu vườn” giữa Hà Nội mộng mơ</h3>
              </div>
            </a>
          </div>

          <div class="blog-item"><a href="#">
              <div class="inner-image"><img
                  src="https://s3.hcm-1.cloud.cmctelecom.vn/vtv-image/Images/Tour/tfd_241021023629_100893_TQ%20(4).jpg"
                  alt=""></div>
              <div class="inner-content">
                <div class="inner-date">23/05/2024</div>
                <h3 class="inner-title">Homestay “khu vườn” giữa Hà Nội mộng mơ</h3>
              </div>
            </a>
          </div>

          <div class="blog-item"><a href="#">
              <div class="inner-image"><img
                  src="https://s3.hcm-1.cloud.cmctelecom.vn/vtv-image/Images/Tour/tfd__1_12185_tokyoakihabara.webp"
                  alt=""></div>
              <div class="inner-content">
                <div class="inner-date">23/05/2024</div>
                <h3 class="inner-title">Homestay “khu vườn” giữa Hà Nội mộng mơ</h3>
              </div>
            </a>
          </div>

          <div class="blog-item"><a href="#">
              <div class="inner-image"><img
                  src="https://s3.hcm-1.cloud.cmctelecom.vn/vtv-image/Images/Tour/tfd__2_12185_7.webp" alt=""></div>
              <div class="inner-content">
                <div class="inner-date">23/05/2024</div>
                <h3 class="inner-title">Homestay “khu vườn” giữa Hà Nội mộng mơ</h3>
              </div>
            </a>
          </div>

          <div class="blog-item"><a href="#">
              <div class="inner-image"><img
                  src="https://s3.hcm-1.cloud.cmctelecom.vn/vtv-image/Images/Tour/tfd__0_11368_table-mountain-cape-town--africa.webp"
                  alt=""></div>
              <div class="inner-content">
                <div class="inner-date">23/05/2024</div>
                <h3 class="inner-title">Homestay “khu vườn” giữa Hà Nội mộng mơ</h3>
              </div>
            </a>
          </div>

          <div class="blog-item"><a href="#">
              <div class="inner-image"><img
                  src="https://s3.hcm-1.cloud.cmctelecom.vn/vtv-image/Images/Tour/tfd__2_11368_johannesburg--africa.webp"
                  alt=""></div>
              <div class="inner-content">
                <div class="inner-date">23/05/2024</div>
                <h3 class="inner-title">Homestay “khu vườn” giữa Hà Nội mộng mơ</h3>
              </div>
            </a>
          </div>






        </div>
      </div>
    </div>

  </main>

</body>

</html>