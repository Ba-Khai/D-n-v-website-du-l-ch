<?php
function asset_url(string $path): string {
  $base = rtrim((string) (defined('BASE_URL') ? BASE_URL : ''), '/');
  return $base . '/' . ltrim($path, '/');
}

function is_logged_in(): bool {
  return !empty($_SESSION['user']);
}

function current_user() {
  return $_SESSION['user'] ?? null;
}

function require_login() {
  if (!is_logged_in()) {
    header("Location: " . asset_url("login.php"));
    exit;
  }
}

function is_admin(): bool {
  return isset($_SESSION['user']) && ($_SESSION['user']['role'] ?? '') === 'admin';
}

function require_admin() {
  if (!is_admin()) {
    header("Location: " . asset_url("login.php"));
    exit;
  }
}

function flash(string $key, string $message = null) {
  if ($message !== null) {
    $_SESSION['flash'][$key] = $message;
    return;
  }
  if (!empty($_SESSION['flash'][$key])) {
    $msg = $_SESSION['flash'][$key];
    unset($_SESSION['flash'][$key]);
    return $msg;
  }
  return null;
}

function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function get_site_settings(PDO $pdo) {
  $row = $pdo->query("SELECT * FROM site_settings LIMIT 1")->fetch(PDO::FETCH_ASSOC);
  if (!$row) {
    $pdo->exec("INSERT INTO site_settings(site_name, logo_url, homepage_hero, about_html, payment_info_json) VALUES('TourX', '', 'Khám phá thế giới cùng TourX', '<p>Về chúng tôi</p>', '{}')");
    $row = $pdo->query("SELECT * FROM site_settings LIMIT 1")->fetch(PDO::FETCH_ASSOC);
  }
  return $row;
}

function money($n) {
  return number_format((float)$n, 0, ',', '.') . ' đ';
}

function post($key, $default='') {
  return trim($_POST[$key] ?? $default);
}
?>
