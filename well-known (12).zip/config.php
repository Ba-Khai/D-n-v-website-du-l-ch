<?php
if (session_status() === PHP_SESSION_NONE)
  session_start();
define('DB_HOST', 'localhost');
define('DB_NAME', 'test');
define('DB_USER', 'root');
define('DB_PASS', '');
define('BASE_URL', ''); // e.g. '/tourapp' if you put the app in a subfolder

date_default_timezone_set('Asia/Ho_Chi_Minh');

try {
  $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
  ]);
} catch (PDOException $e) {
  die("ktmphp erorr " . $e->getMessage());
}

require_once __DIR__ . '/functions.php';
$settings = get_site_settings($pdo);

###
define("MOMO_ENDPOINT", "https://test-payment.momo.vn/v2/gateway/api/create");
define("MOMO_PARTNER_CODE", "MOMOXXXX2023");
define("MOMO_ACCESS_KEY", "xxxxxxx");
define("MOMO_SECRET_KEY", "xxxxxxx");
define("MOMO_RETURN_URL", "http://localhost/return_momo.php");
define("MOMO_NOTIFY_URL", "http://localhost/notify_momo.php");

// Cấu hình VNPAY
define("VNPAY_TMN_CODE", "XXXXXX");
define("VNPAY_HASH_SECRET", "xxxxxxxxxxxxxxxx");
define("VNPAY_URL", "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html");
define("VNPAY_RETURN_URL", "http://localhost/return_vnpay.php");
?>