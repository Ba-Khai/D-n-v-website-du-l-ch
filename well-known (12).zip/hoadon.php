<?php
require_once __DIR__ . '/config.php';
require_login();

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT b.*, 
                              t.name as tour_name, t.code as tour_code, t.departure, t.start_date, t.end_date, t.price as tour_price,
                              r.name as room_name, r.price as room_price, r.hotel_name, r.location
                       FROM bookings b
                       JOIN tours t ON b.tour_id = t.id
                       JOIN rooms r ON b.room_id = r.id
                       WHERE b.id=? AND b.user_id=?");
$stmt->execute([$id, current_user()['id']]);
$booking = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$booking) {
    echo "<div class='alert alert-danger'>Không tìm thấy hóa đơn.</div>";
    require 'footer.php';
    exit;
}
?>

<?php require_once __DIR__ . '/header.php'; ?>
<link rel="stylesheet" href="assets/css/layout.css">
<link rel="stylesheet" href="assets/css/thong-tin-tour.css">
<section id="section-hero">
            <div class="container">
              <h2>Đặt tour thành công</h2>
            </div>
          </section>
<div class="container my-4">
  <div class="card shadow-sm p-4">
    <h3 class="mb-3">🧾 Hóa đơn đặt tour</h3>
    <p><b>Mã đặt:</b> #<?= (int)$booking['id'] ?></p>
    <p><b>Ngày đặt:</b> <?= h($booking['created_at']) ?></p>
    <hr>
    <h5>Thông tin khách hàng</h5>
    <p><b>Họ tên:</b> <?= h($booking['customer_name']) ?></p>
    <p><b>SĐT:</b> <?= h($booking['phone']) ?></p>
    <?php if ($booking['note']): ?>
      <p><b>Ghi chú:</b> <?= h($booking['note']) ?></p>
    <?php endif; ?>
    <hr>
    <h5>Thông tin tour</h5>
    <p><b>Tên tour:</b> <?= h($booking['tour_name']) ?> (<?= h($booking['tour_code']) ?>)</p>
    <p><b>Khởi hành:</b> <?= h($booking['departure']) ?> • <?= h($booking['start_date']) ?></p>
    <p><b>Ngày về:</b> <?= h($booking['end_date']) ?></p>
    <p><b>Giá tour:</b> <?= money($booking['tour_price']) ?></p>
    <hr>
    <h6>Phòng đã chọn</h6>
    <p><b><?= h($booking['room_name']) ?></b> • <?= money($booking['room_price']) ?>/đêm</p>
    <p>KS: <?= h($booking['hotel_name']) ?> - <?= h($booking['location']) ?></p>
    <hr>
    <h5>Thanh toán</h5>
    <p><b>Phương thức:</b> <?= h($booking['payment_method']) ?></p>
    <p><b>Tổng tiền:</b> <span class="fw-bold text-danger"><?= money($booking['total_price']) ?></span></p>
    <?php if ($booking['payment_method'] === 'TIEN_MAT'): ?>
      <div class="alert alert-info mt-3">Vui lòng thanh toán trực tiếp khi đi tour.</div>
    <?php endif; ?>
  </div>
</div>
<?php require_once __DIR__ . '/footer.php'; ?>
