<?php require_once __DIR__ . '/header.php'; 
$tid = (int)($_GET['tour_id'] ?? 0);
$rid = (int)($_GET['room_id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM tours WHERE id=?");
$stmt->execute([$tid]);
$t = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$t) { 
  echo '<div class="alert alert-danger">Tour không tồn tại.</div>'; 
  require 'footer.php'; 
  exit; 
}
$rooms = $pdo->prepare("SELECT * FROM rooms WHERE tour_id=? ORDER BY price ASC");
$rooms->execute([$tid]);
$rs = $rooms->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="container py-4">
  <h3 class="mb-4 text-primary">
    Chọn phòng - <?php echo h($t['name']); ?>
  </h3>

  <div class="row">
    <div class="col-lg-8">
      <?php foreach ($rs as $r): ?>
        <?php 
          $imgsStmt = $pdo->prepare("SELECT image_url FROM room_images WHERE room_id=? ORDER BY id ASC");
          $imgsStmt->execute([$r['id']]);
          $imgs = $imgsStmt->fetchAll(PDO::FETCH_COLUMN);
        ?>
        <div class="card mb-4 border-0">
          <div class="row g-0">
            <!-- ảnh -->
            <div class="col-md-5">
              <?php if ($imgs): ?>
                <img src="<?php echo h($imgs[0]); ?>" class="w-100 h-100 object-fit-cover" alt="room">
              <?php else: ?>
                <img src="<?php echo asset_url('images/no-image.png'); ?>" class="w-100 h-100 object-fit-cover" alt="no-image">
              <?php endif; ?>
            </div>
            <!-- nội dung -->
            <div class="col-md-7">
              <div class="card-body">
                <h5 class="card-title d-flex justify-content-between">
                  <span><?php echo h($r['name']); ?></span>
                  <span class="text-success"><?php echo money($r['price']); ?>/đêm</span>
                </h5>
                <p class="text-muted mb-1"><?php echo h($r['hotel_name']); ?></p>
                <p class="mb-1"><?php echo h($r['area']); ?> m² • <?php echo h($r['bed_type']); ?></p>
                <p class="mb-1">Tối đa <?php echo (int)$r['max_guests']; ?> khách</p>
                <p class="mb-1">Còn lại <b><?php echo (int)$r['remaining']; ?></b> phòng</p>
                <?php $opts = json_decode($r['options_json'] ?? '[]', true) ?: []; ?>
                <?php if ($opts): ?>
                                <p>Mô tả thêm: </p>

                  <ul class="small mb-2">
                    <?php foreach ($opts as $o): ?><li><?php echo h($o); ?></li><?php endforeach; ?>
                  </ul>
                <?php endif; ?>
                <a class="btn btn-primary w-100" href="<?php echo asset_url('checkout.php?tour_id='.(int)$t['id'].'&room_id='.(int)$r['id']); ?>">
                  Đặt tour
                </a>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; if (!$rs): ?>
        <div class="alert alert-info">Chưa có phòng.</div>
      <?php endif; ?>
    </div>

    <!-- Thông tin tour -->
    <div class="col-lg-4">
      <div class="card bg-light border-0">
        <div class="card-body">
          <h5 class="mb-3">Thông tin tour</h5>
          <p>Khởi hành: <b><?php echo h($t['departure']); ?></b></p>
          <p>Ngày: <b><?php echo h($t['start_date']); ?> - <?php echo h($t['end_date']); ?></b> (<?php echo (int)$t['duration_days']; ?>N)</p>
          <p>Giá tour: <b class="text-success"><?php echo money($t['price']); ?></b></p>
        </div>
      </div>
    </div>
  </div>
</div>


<?php require_once __DIR__ . '/footer.php'; ?>
