<?php 
require_once __DIR__ . '/config.php'; 
require_login();

$uid = (int)current_user()['id'];
$tid = (int)($_POST['tour_id'] ?? 0);
$rid = (int)($_POST['room_id'] ?? 0);
$customer_name = post('customer_name');
$phone = post('phone');
$note = post('note');
$payment_method = post('payment_method');

$t = $pdo->prepare("SELECT * FROM tours WHERE id=?");
$t->execute([$tid]);
$t = $t->fetch(PDO::FETCH_ASSOC);

$r = $pdo->prepare("SELECT * FROM rooms WHERE id=? AND tour_id=?");
$r->execute([$rid,$tid]);
$r = $r->fetch(PDO::FETCH_ASSOC);

if (!$t || !$r || !$customer_name || !$phone || !in_array($payment_method, ['MOMO','VNPAY','TIEN_MAT'])) {
  flash('err','Dữ liệu không hợp lệ'); 
  header("Location: index.php"); 
  exit;
}

$total = (float)$t['price'] + (float)$r['price'];

$ins = $pdo->prepare("INSERT INTO bookings(user_id,tour_id,room_id,customer_name,phone,note,payment_method,total_price,status) 
VALUES(?,?,?,?,?,?,?,?, 'pending')");
$ins->execute([$uid,$tid,$rid,$customer_name,$phone,$note,$payment_method,$total]);

$booking_id = $pdo->lastInsertId(); // lấy ID đơn mới tạo

if ($payment_method === 'TIEN_MAT') {
    flash('ok','Đặt tour thành công! Vui lòng thanh toán trực tiếp khi đi tour.');
    header("Location: " . asset_url("hoadon.php?id=" . $booking_id));
    exit;
}


// =========================
// MOMO
// =========================
if ($payment_method === 'MOMO') {
    $endpoint = "https://test-payment.momo.vn/gw_payment/transactionProcessor";
    $partnerCode = MOMO_PARTNER_CODE;
    $accessKey = MOMO_ACCESS_KEY;
    $secretKey = MOMO_SECRET_KEY;

    $orderInfo = "Thanh toán tour #" . $bookingId;
    $returnUrl = BASE_URL . "/return_momo.php";
    $notifyUrl = BASE_URL . "/notify_momo.php";
    $orderId = $bookingId;
    $requestId = time() . "";
    $extraData = "";

    $rawHash = "partnerCode=".$partnerCode
        ."&accessKey=".$accessKey
        ."&requestId=".$requestId
        ."&amount=".$total
        ."&orderId=".$orderId
        ."&orderInfo=".$orderInfo
        ."&returnUrl=".$returnUrl
        ."&notifyUrl=".$notifyUrl
        ."&extraData=".$extraData;

    $signature = hash_hmac("sha256", $rawHash, $secretKey);

    $data = [
        'partnerCode' => $partnerCode,
        'accessKey' => $accessKey,
        'requestId' => $requestId,
        'amount' => $total,
        'orderId' => $orderId,
        'orderInfo' => $orderInfo,
        'returnUrl' => $returnUrl,
        'notifyUrl' => $notifyUrl,
        'extraData' => $extraData,
        'requestType' => 'captureMoMoWallet',
        'signature' => $signature
    ];

    $ch = curl_init($endpoint);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $result = curl_exec($ch);
    curl_close($ch);

    $jsonResult = json_decode($result, true);
    if (isset($jsonResult['payUrl'])) {
        header('Location: ' . $jsonResult['payUrl']);
        exit;
    } else {
        flash('err','Không thể kết nối MOMO.');
        header("Location: index.php");
        exit;
    }
}

// =========================
// VNPAY
// =========================
if ($payment_method === 'VNPAY') {
    $vnp_Url = "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html";
    $vnp_Returnurl = BASE_URL . "/return_vnpay.php";
    $vnp_TmnCode = VNPAY_TMN_CODE;
    $vnp_HashSecret = VNPAY_HASH_SECRET;

    $vnp_TxnRef = $bookingId;
    $vnp_OrderInfo = "Thanh toán tour #" . $bookingId;
    $vnp_OrderType = "billpayment";
    $vnp_Amount = $total * 100; // VNPAY tính theo VNĐ * 100
    $vnp_Locale = "vn";
    $vnp_BankCode = "VNBANK";
    $vnp_IpAddr = $_SERVER['REMOTE_ADDR'];

    $inputData = [
        "vnp_Version" => "2.1.0",
        "vnp_TmnCode" => $vnp_TmnCode,
        "vnp_Amount" => $vnp_Amount,
        "vnp_Command" => "pay",
        "vnp_CreateDate" => date('YmdHis'),
        "vnp_CurrCode" => "VND",
        "vnp_IpAddr" => $vnp_IpAddr,
        "vnp_Locale" => $vnp_Locale,
        "vnp_OrderInfo" => $vnp_OrderInfo,
        "vnp_OrderType" => $vnp_OrderType,
        "vnp_ReturnUrl" => $vnp_Returnurl,
        "vnp_TxnRef" => $vnp_TxnRef,
    ];

    ksort($inputData);
    $hashData = urldecode(http_build_query($inputData));
    $vnp_SecureHash = hash_hmac('sha512', $hashData, $vnp_HashSecret);
    $inputData['vnp_SecureHash'] = $vnp_SecureHash;

    $vnp_Url = $vnp_Url . "?" . http_build_query($inputData);
    header('Location: ' . $vnp_Url);
    exit;
}
