<?php
// Link bài viết (dùng link đầy đủ, có id post rõ ràng)
$url = "https://www.facebook.com/share/p/1GPH2D9sSa/";

// Cookie copy từ trình duyệt (chuỗi dài)
$cookie = "datr=u9cIaBWh1MjHW2wNzFtK8lpO; sb=u9cIaFO9_GT27frdQ9GYmnNW; ps_l=1; ps_n=1; oo=v1; c_user=100066429831280; dpr=1.125; xs=18%3AQJ1epz5Wx7xd9w%3A2%3A1755836939%3A-1%3A-1%3A%3AAcXZKVNPzUcebT3HlTlFSrWuBy3nwEZoJd1koHQGRkA; fr=1RqZX6XWiiIXst7k8.AWf9ihHFRo7fxpoeQutWdha_iget7krIJtz4F13vljvsOhNu1tM.BovQt3..AAA.0.0.BovQwg.AWcvjPMrYve-eK72DmGrRZmEgQQ; wd=1707x780; presence=C%7B%22t3%22%3A%5B%5D%2C%22utc3%22%3A1757219882191%2C%22v%22%3A1%7D";

// Khởi tạo cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Cookie: $cookie",
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
]);

$html = curl_exec($ch);
curl_close($ch);

// Kiểm tra kết quả
if (!$html) {
    die("Không lấy được dữ liệu");
}

// Parse đơn giản: ví dụ lấy <meta property="og:description"> (status tóm tắt)
if (preg_match('/<meta property="og:description" content="(.*?)"/', $html, $m)) {
    echo "Status: " . htmlspecialchars($m[1]) . "<br>";
}

// Lấy ảnh (og:image)
if (preg_match('/<meta property="og:image" content="(.*?)"/', $html, $m)) {
    echo "Ảnh: <img src='" . htmlspecialchars($m[1]) . "' width='300'><br>";
}

// Comment đầu tiên: cái này khó, vì phải parse HTML động hoặc JSON embedded
if (preg_match('/"comment_count":{"count":(\d+)}/', $html, $m)) {
    echo "Có " . $m[1] . " comment (khó lấy trực tiếp comment nội dung).";
}
?>
