<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tổng quan</title>

</head>

<body>
  <?php
  require_once __DIR__ . '/header.php';

  // Lấy từ khóa tìm kiếm
  $q = trim($_GET['q'] ?? '');
  $sql = "SELECT * FROM tours WHERE 1";
  $params = [];

  if ($q !== '') {
    $sql .= " AND (name LIKE ? OR destination LIKE ? OR tour_type LIKE ?)";
    $params = ["%$q%", "%$q%", "%$q%"];
  }

  // Nếu có tìm thì limit 50, còn không thì show hết
  if ($q !== '') {
    $sql .= " ORDER BY created_at DESC LIMIT 50";
  } else {
    $sql .= " ORDER BY created_at DESC";
  }

  $stmt = $pdo->prepare($sql);
  $stmt->execute($params);
  $tours = $stmt->fetchAll(PDO::FETCH_ASSOC);
  ?>

  <main class="main">



    <!-- Font Awesome 6 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
    <style>
      :root {
        --brand: #0d6efd;
        /* primary */
        --ink: #1f2937;
        /* text */
        --muted: #6b7280;
        /* secondary text */
        --bg-soft: #f8fafc;
        /* section bg */
        --card: #ffffff;
        /* card bg */
        --radius: 1.25rem;
        /* 20px rounded */
        --shadow: 0 10px 30px rgba(2, 6, 23, .06);
      }

      body {
        color: var(--ink);
      }

      .section {
        padding: 72px 0;
      }

      /* Hero */
      .hero {
        background: radial-gradient(1000px 400px at 80% -10%, rgba(13, 110, 253, .12), transparent),
          radial-gradient(900px 300px at 10% 0%, rgba(13, 110, 253, .08), transparent),
          linear-gradient(180deg, #fff 0%, var(--bg-soft) 100%);
      }

      .hero-badge {
        font-size: .85rem;
        letter-spacing: .06em;
      }

      /* Cards */
      .feature-card {
        background: var(--card);
        border: 0;
        border-radius: var(--radius);
        box-shadow: var(--shadow);
        height: 100%;
      }

      .feature-card .icon-wrap {
        width: 56px;
        height: 56px;
        display: grid;
        place-items: center;
        border-radius: 14px;
        background: #eef5ff;
      }

      /* Stats */
      .stat {
        border-radius: var(--radius);
        background: var(--card);
        box-shadow: var(--shadow);
      }

      .stat h3 {
        margin: 0;
        font-weight: 800;
      }

      /* Timeline */
      .timeline {
        position: relative;
      }

      .timeline:before {
        content: "";
        position: absolute;
        top: 0;
        bottom: 0;
        left: 18px;
        width: 2px;
        background: #e5e7eb;
      }

      .timeline-item {
        position: relative;
        padding-left: 56px;
      }

      .timeline-item .dot {
        position: absolute;
        left: 10px;
        top: .35rem;
        width: 16px;
        height: 16px;
        background: var(--brand);
        border-radius: 50%;
        box-shadow: 0 0 0 6px #eaf2ff;
      }

      /* CTA */
      .cta {
        background: linear-gradient(135deg, #0d6efd 0%, #4f46e5 100%);
        color: #fff;
        border-radius: calc(var(--radius) + .5rem);
        box-shadow: var(--shadow);
      }

      .cta .btn {
        box-shadow: 0 10px 20px rgba(0, 0, 0, .1);
      }

      /* Footer mini */
      .mini-footer {
        color: var(--muted);
        font-size: .9rem;
      }

      /* Utility */
      .rounded-2xl {
        border-radius: var(--radius) !important;
      }
    </style>
    </head>

    <body>

      <!-- HERO -->
      <header class="hero section">
        <div class="container">
          <div class="row align-items-center g-4">
            <div class="col-lg-6">
              <span class="hero-badge badge bg-primary-subtle text-primary rounded-pill mb-3">
                <i class="fa-solid fa-earth-asia me-1"></i> TourPlus – Hành trình hạnh phúc
              </span>
              <h1 class="display-5 fw-bold mb-3">Công ty Du lịch TourPlus</h1>
              <p class="lead text-secondary">Chúng tôi thiết kế tour thông minh, dịch vụ tận tâm và trải nghiệm bản địa
                chân thật. Hơn 120.000 khách đã đồng hành cùng TourPlus suốt 10+ năm qua.</p>
              <div class="d-flex gap-3 mt-4">
                <a href="#ve-chung-toi" class="btn btn-primary btn-lg"><i class="fa-solid fa-circle-info me-2"></i>Về
                  chúng tôi</a>
                <a href="#gia-tri" class="btn btn-outline-primary btn-lg"><i class="fa-solid fa-compass me-2"></i>Giá
                  trị cốt lõi</a>
              </div>
            </div>
            <div class="col-lg-6">
              <img src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1600&auto=format&fit=crop"
                alt="Bãi biển xanh mát" class="img-fluid rounded-2xl shadow" />
            </div>
          </div>
        </div>
      </header>

      <!-- ABOUT -->
      <section id="ve-chung-toi" class="section">
        <div class="container">
          <div class="row g-4 align-items-center">
            <div class="col-lg-5">
              <img src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?q=80&w=1200&auto=format&fit=crop"
                alt="Khách du lịch đang cười" class="img-fluid rounded-2xl shadow" />
            </div>
            <div class="col-lg-7">
              <h2 class="fw-bold mb-3">Chúng tôi là ai?</h2>
              <p class="mb-3 text-secondary">TourPlus là công ty lữ hành chuyên tour trong nước & quốc tế, MICE, team
                building và thiết kế hành trình theo yêu cầu. Sứ mệnh của chúng tôi là <strong>giúp mọi chuyến đi trở
                  nên đơn giản, an toàn và đầy cảm hứng</strong>.</p>
              <div class="row g-3">
                <div class="col-md-6">
                  <div class="card feature-card p-3">
                    <div class="d-flex align-items-start gap-3">
                      <div class="icon-wrap"><i class="fa-solid fa-user-shield"></i></div>
                      <div>
                        <h5 class="mb-1">Uy tín & minh bạch</h5>
                        <p class="mb-0 text-secondary">Đối tác được kiểm chứng, giá rõ ràng, hợp đồng & hóa đơn đầy đủ.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="card feature-card p-3">
                    <div class="d-flex align-items-start gap-3">
                      <div class="icon-wrap"><i class="fa-solid fa-route"></i></div>
                      <div>
                        <h5 class="mb-1">Lịch trình linh hoạt</h5>
                        <p class="mb-0 text-secondary">Tối ưu thời gian di chuyển, nhiều tùy chọn nâng cấp trải nghiệm.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="card feature-card p-3">
                    <div class="d-flex align-items-start gap-3">
                      <div class="icon-wrap"><i class="fa-solid fa-headset"></i></div>
                      <div>
                        <h5 class="mb-1">Hỗ trợ 24/7</h5>
                        <p class="mb-0 text-secondary">Trợ lý du lịch theo sát, xử lý nhanh mọi tình huống phát sinh.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="card feature-card p-3">
                    <div class="d-flex align-items-start gap-3">
                      <div class="icon-wrap"><i class="fa-solid fa-tags"></i></div>
                      <div>
                        <h5 class="mb-1">Giá tốt nhất</h5>
                        <p class="mb-0 text-secondary">Đàm phán giá sỉ, nhiều ưu đãi theo mùa, hoàn tiền nếu rẻ hơn.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- STATS -->
      <section class="section" style="background:var(--bg-soft)">
        <div class="container">
          <div class="row g-3">
            <div class="col-6 col-lg-3">
              <div class="stat p-4 text-center">
                <h3 class="display-6">10+</h3>
                <p class="text-secondary mb-0">Năm kinh nghiệm</p>
              </div>
            </div>
            <div class="col-6 col-lg-3">
              <div class="stat p-4 text-center">
                <h3 class="display-6">120K</h3>
                <p class="text-secondary mb-0">Khách hàng hài lòng</p>
              </div>
            </div>
            <div class="col-6 col-lg-3">
              <div class="stat p-4 text-center">
                <h3 class="display-6">800+</h3>
                <p class="text-secondary mb-0">Đối tác toàn cầu</p>
              </div>
            </div>
            <div class="col-6 col-lg-3">
              <div class="stat p-4 text-center">
                <h3 class="display-6">4.8/5</h3>
                <p class="text-secondary mb-0">Điểm hài lòng trung bình</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- VALUES -->
      <section id="gia-tri" class="section">
        <div class="container">
          <div class="row mb-4">
            <div class="col-lg-8">
              <h2 class="fw-bold">Giá trị cốt lõi</h2>
              <p class="text-secondary">An toàn – Tận tâm – Sáng tạo – Bền vững. Mọi quyết định đều hướng tới trải
                nghiệm khách hàng tốt nhất.</p>
            </div>
          </div>
          <div class="row g-4">
            <div class="col-md-4">
              <div class="card feature-card p-4 h-100">
                <i class="fa-solid fa-shield-heart fa-2x mb-3"></i>
                <h5>Ưu tiên an toàn</h5>
                <p class="text-secondary mb-0">Chuẩn bị kỹ lưỡng, bảo hiểm du lịch và tiêu chuẩn an toàn được cập nhật
                  định kỳ.</p>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card feature-card p-4 h-100">
                <i class="fa-solid fa-hand-holding-heart fa-2x mb-3"></i>
                <h5>Phục vụ bằng trái tim</h5>
                <p class="text-secondary mb-0">Tư vấn chân thành, cam kết đồng hành trước – trong – sau chuyến đi.</p>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card feature-card p-4 h-100">
                <i class="fa-solid fa-seedling fa-2x mb-3"></i>
                <h5>Du lịch xanh</h5>
                <p class="text-secondary mb-0">Ưu tiên nhà cung cấp bền vững, giảm nhựa dùng một lần và ủng hộ cộng đồng
                  địa phương.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- TIMELINE -->
      <section class="section" style="background:var(--bg-soft)">
        <div class="container">
          <div class="row g-4 align-items-center">
            <div class="col-lg-6">
              <h2 class="fw-bold mb-3">Hành trình phát triển</h2>
              <div class="timeline">
                <div class="timeline-item mb-4">
                  <span class="dot"></span>
                  <h6 class="mb-1">2015</h6>
                  <p class="text-secondary mb-0">Thành lập TourPlus với đội ngũ 5 người đam mê du lịch.</p>
                </div>
                <div class="timeline-item mb-4">
                  <span class="dot"></span>
                  <h6 class="mb-1">2018</h6>
                  <p class="text-secondary mb-0">Mở rộng tour Đông Nam Á & đạt mốc 20.000 khách.</p>
                </div>
                <div class="timeline-item mb-4">
                  <span class="dot"></span>
                  <h6 class="mb-1">2022</h6>
                  <p class="text-secondary mb-0">Ra mắt nền tảng đặt tour trực tuyến, tích hợp thanh toán đa kênh.</p>
                </div>
                <div class="timeline-item">
                  <span class="dot"></span>
                  <h6 class="mb-1">2025</h6>
                  <p class="text-secondary mb-0">Đạt chuẩn bền vững Travelife, hợp tác 800+ đối tác toàn cầu.</p>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <img src="https://statics.vinpearl.com/diem-du-lich-01_1632671030%20(1)_1661249974.jpg"
                alt="Lịch trình trên bản đồ" class="img-fluid rounded-2xl shadow" />
            </div>
          </div>
        </div>
      </section>

      <!-- CTA -->
      <section class="section">
        <div class="container">
          <div class="cta p-5 p-lg-6">
            <div class="row align-items-center g-4">
              <div class="col-lg-8">
                <h2 class="fw-bold mb-2">Sẵn sàng cho hành trình tiếp theo?</h2>
                <p class="mb-0">Liên hệ đội ngũ tư vấn TourPlus để nhận lịch trình tối ưu & báo giá tốt nhất trong 24h.
                </p>
              </div>
              <div class="col-lg-4 text-lg-end">
                <a href="tel:0372648522" class="btn btn-light btn-lg me-2"><i
                    class="fa-solid fa-phone-volume me-2"></i>Gọi ngay</a>
                <a href="mailto:hotro@tenmien.com" class="btn btn-outline-light btn-lg"><i
                    class="fa-regular fa-paper-plane me-2"></i>Nhận tư
                  vấn</a>


              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- MINI FOOTER (không có nút mạng xã hội) -->
      <footer class="py-4 mini-footer">
        <div class="container d-flex flex-column flex-lg-row align-items-center justify-content-between gap-2">
          <div>© <span id="y"></span> TourPlus Co., Ltd. Mọi quyền được bảo lưu.</div>
          <div class="small">Hotline: 1900 1234 • Email: hello@tourplus.vn • MST: 0123456789</div>
        </div>
      </footer>

      <script>
        document.getElementById('y').textContent = new Date().getFullYear();
      </script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>



  </main>

</body>

</html>