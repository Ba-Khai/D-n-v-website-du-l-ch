  <div class="section-5"> 
        <div class="container"> 
          <div class="inner-wrap"> 
            <h2 class="inner-title">
               Đăng ký ngay để không bỏ lỡ các chương trình của chúng tôi</h2>
            <form class="inner-form" action="">
              <input type="email" placeholder="Nhập email của bạn...">
              <button>
                 Đăng ký ngay</button>
            </form>
          </div>
        </div>
      </div>
      <nav class="box-contact"> 
        <ul> 
          <li><a href="#"><i class="fa-brands fa-facebook-f"></i></a></li>
          <li> <a href="#"><i class="fa-brands fa-instagram"> </i></a></li>
          <li> <a href="#"><i class="fa-brands fa-whatsapp"></i></a></li>
          <li> <a href="#"><i class="fa-brands fa-youtube"> </i></a></li>
        </ul>
      </nav>
    </main>
    <footer class="footer"> 
      <div class="container">
        <div class="footer-connect">
          <div class="entire-info-website">
            <div class="title-footer">
               Liên hệ</div>
            <div class="address-footer"> 
              <p> <b>CÔNG TY CỔ PHẦN DU LỊCH BKQ</b></p>
              <p>
                 SỐ 01, Đ.QUANG TRUNG, P.HẢI CHÂU 1, Q.HẢI CHÂU, TP.ĐÀ NẴNG.</p>
              <p>
                 HotLine: 091234524</p>
              <p>
                 Email: info@BKQ.com</p>
              <p>
                 Mã số doanh nghiệp: 0110376372 do Sở Kế hoạch và Đầu tư Thành phố Hà Nội cấp ngày 05/06/2023</p>
            </div>
          </div>
          <div class="footer-menu-section">
            <div class="title-footer">BKQ.com </div>
            <ul class="list-unstyled">
              <li> <a href="#">Giới thiệu</a></li>
              <li> <a href="#">Về chúng tôi </a></li>
              <li> <a href="#">Blog</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div class="footer-copyright"> 
        <div class="container">
           Copyright 2022 BKQ.com - All Rights Reserved</div>
      </div>
    </footer>