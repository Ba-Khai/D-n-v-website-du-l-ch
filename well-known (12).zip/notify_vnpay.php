<?php
require 'config.php';

$vnp_SecureHash = $_GET['vnp_SecureHash'] ?? '';
$inputData = [];
foreach ($_GET as $key => $value) {
    if (substr($key, 0, 4) == "vnp_") {
        $inputData[$key] = $value;
    }
}
unset($inputData['vnp_SecureHash']);
ksort($inputData);

$hashData = urldecode(http_build_query($inputData));
$secureHash = hash_hmac('sha512', $hashData, VNPAY_HASH_SECRET);

// Kiểm tra chữ ký
if ($secureHash === $vnp_SecureHash) {
    $bookingId = $_GET['vnp_TxnRef'] ?? 0;
    if ($_GET['vnp_ResponseCode'] == '00') {
        $stmt = $pdo->prepare("UPDATE bookings SET status='paid' WHERE id=?");
        $stmt->execute([$bookingId]);
        echo "OK";
    } else {
        echo "FAILED";
    }
} else {
    echo "INVALID HASH";
}
