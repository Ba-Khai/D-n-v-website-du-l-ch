<?php
require_once __DIR__ . '/config.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tour_id = (int)($_POST['tour_id'] ?? 0);
    $rating  = (int)($_POST['rating'] ?? 0);
    $comment = trim($_POST['comment'] ?? '');

    if ($tour_id && $rating >= 1 && $rating <= 5 && $comment) {
        $stmt = $pdo->prepare("INSERT INTO reviews (tour_id, user_id, rating, comment) VALUES (?,?,?,?)");
        $stmt->execute([$tour_id, $_SESSION['user']['id'], $rating, $comment]);
        flash('ok', 'Cảm ơn bạn đã đánh giá!');
    } else {
        flash('error', 'Vui lòng nhập đầy đủ thông tin.');
    }

    header("Location: tour.php?id=".$tour_id);
    exit;
}
