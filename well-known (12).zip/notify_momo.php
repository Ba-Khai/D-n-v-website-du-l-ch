<?php
require 'config.php';

$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    http_response_code(400);
    echo "Invalid request";
    exit;
}
$rawHash = "accessKey=" . MOMO_ACCESS_KEY .
    "&amount=" . $data['amount'] .
    "&extraData=" . $data['extraData'] .
    "&message=" . $data['message'] .
    "&orderId=" . $data['orderId'] .
    "&orderInfo=" . $data['orderInfo'] .
    "&orderType=" . $data['orderType'] .
    "&partnerCode=" . $data['partnerCode'] .
    "&payType=" . $data['payType'] .
    "&requestId=" . $data['requestId'] .
    "&responseTime=" . $data['responseTime'] .
    "&resultCode=" . $data['resultCode'] .
    "&transId=" . $data['transId'];

$signature = hash_hmac("sha256", $rawHash, MOMO_SECRET_KEY);

if ($signature === $data['signature'] && $data['resultCode'] == '0') {
    // Thành công
    $stmt = $pdo->prepare("UPDATE bookings SET status='paid' WHERE id=?");
    $stmt->execute([$data['orderId']]);
    echo json_encode(["message" => "success"]);
} else {
    echo json_encode(["message" => "invalid signature"]);
}
