<?php require_once __DIR__ . '/../config.php'; require_admin();
$action = $_GET['action'] ?? '';
$id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD']==='POST' && ($action==='create' || $action==='edit')) {
  $data = [
    'tour_id' => (int)post('tour_id'),
    'name' => post('name'),
    'area' => post('area'),
    'max_guests' => (int)post('max_guests'),
    'bed_type' => post('bed_type'),
    'price' => (float)post('price'),
    'location' => post('location'),
    'hotel_name' => post('hotel_name'),
    'hotel_address' => post('hotel_address'),
    'hotel_description' => post('hotel_description'),
    'remaining' => (int)post('remaining'),
    'options_json' => json_encode(array_filter(array_map('trim', explode("\n", post('options'))))),
  ];

  if ($action==='create') {
    $sql = "INSERT INTO rooms(tour_id,name,area,max_guests,bed_type,price,location,hotel_name,hotel_address,hotel_description,remaining,options_json)
            VALUES(:tour_id,:name,:area,:max_guests,:bed_type,:price,:location,:hotel_name,:hotel_address,:hotel_description,:remaining,:options_json)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($data);
    $room_id = $pdo->lastInsertId();
  } else {
    $data['id'] = $id;
    $sql = "UPDATE rooms SET tour_id=:tour_id,name=:name,area=:area,max_guests=:max_guests,bed_type=:bed_type,price=:price,location=:location,
            hotel_name=:hotel_name,hotel_address=:hotel_address,hotel_description=:hotel_description,remaining=:remaining,options_json=:options_json
            WHERE id=:id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($data);
    $room_id = $id;
  }
  if (!empty($_FILES['images']['name'][0])) {
    $uploadDir = __DIR__ . '/../uploads/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

    foreach ($_FILES['images']['name'] as $k => $fname) {
      if ($_FILES['images']['error'][$k] === UPLOAD_ERR_OK) {
        $ext = pathinfo($fname, PATHINFO_EXTENSION);
        $filename = uniqid('room_').'.'.$ext;
        $targetFile = $uploadDir.$filename;
        if (move_uploaded_file($_FILES['images']['tmp_name'][$k], $targetFile)) {
          $pdo->prepare("INSERT INTO room_images(room_id, image_url, created_at) VALUES(?,?,NOW())")
              ->execute([$room_id, 'uploads/'.$filename]);
        }
      }
    }
  }

  flash('ok','Lưu phòng thành công'); header("Location: rooms.php"); exit;
}

if ($action==='delete' && $id) {
  $pdo->prepare("DELETE FROM rooms WHERE id=?")->execute([$id]);
  $pdo->prepare("DELETE FROM room_images WHERE room_id=?")->execute([$id]);
  flash('ok','Đã xóa phòng'); header("Location: rooms.php"); exit;
}

if ($action==='delimg' && $id) {
  $img_id = (int)($_GET['img'] ?? 0);
  $st = $pdo->prepare("SELECT image_url FROM room_images WHERE id=? AND room_id=?");
  $st->execute([$img_id, $id]);
  if ($row=$st->fetch()) {
    @unlink(__DIR__ . '/../'.$row['image_url']);
    $pdo->prepare("DELETE FROM room_images WHERE id=?")->execute([$img_id]);
    flash('ok','Đã xóa ảnh');
  }
  header("Location: rooms.php?action=edit&id=".$id); exit;
}

$tours = $pdo->query("SELECT id, name FROM tours ORDER BY name")->fetchAll(PDO::FETCH_KEY_PAIR);
$rooms = $pdo->query("SELECT * FROM rooms ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ADMIN</title>
  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

  <style>
    body {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
  
  
  </style>
</head>
<body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container">
      <a class="navbar-brand fw-bold" href="#">
        <i class="fas fa-home me-2"></i>Admin
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="mainNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link active" href="index.php">Trang chủ</a></li>
        </ul>
      </div>
    </div>
  </nav>
<h3>Quản lý phòng</h3>
<?php if ($m=flash('ok')): ?><div class="alert alert-success"><?php echo h($m); ?></div><?php endif; ?>
<div class="row">
  <div class="col-md-4">
    <div class="card"><div class="card-body">
      <h5><?php echo $action==='edit' ? 'Sửa phòng' : 'Tạo phòng'; ?></h5>
      <?php 
      $edit = ['tour_id'=>'','name'=>'','area'=>'30m2','max_guests'=>2,'bed_type'=>'Double','price'=>500000,'location'=>'','hotel_name'=>'','hotel_address'=>'','hotel_description'=>'','remaining'=>5,'options'=>'']; 
      if ($action==='edit' && $id) { 
        $st=$pdo->prepare("SELECT * FROM rooms WHERE id=?"); 
        $st->execute([$id]); 
        $t=$st->fetch(PDO::FETCH_ASSOC); 
        $edit=$t; 
        $edit['options']=implode("\n", json_decode($t['options_json'] ?? '[]', true) ?: []); 
        $images=$pdo->prepare("SELECT * FROM room_images WHERE room_id=?"); 
        $images->execute([$id]); 
        $room_images=$images->fetchAll(PDO::FETCH_ASSOC); 
      } else {
        $room_images=[];
      }
      ?>
      <form method="post" enctype="multipart/form-data" action="?action=<?php echo $action==='edit'?'edit':'create'; ?><?php if($id) echo '&id='.$id; ?>">
        <div class="mb-2"><label class="form-label">Thuộc tour</label>
          <select name="tour_id" class="form-select" required>
            <option value="">-- chọn tour --</option>
            <?php foreach ($tours as $tid=>$tname): ?>
              <option value="<?php echo (int)$tid; ?>" <?php if((int)$edit['tour_id']===(int)$tid) echo 'selected'; ?>><?php echo h($tname); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-2"><label class="form-label">Tên phòng</label><input name="name" class="form-control" required value="<?php echo h($edit['name']); ?>"></div>
        <div class="mb-2"><label class="form-label">Diện tích</label><input name="area" class="form-control" value="<?php echo h($edit['area']); ?>"></div>
        <div class="mb-2"><label class="form-label">Số khách tối đa</label><input type="number" name="max_guests" class="form-control" value="<?php echo (int)$edit['max_guests']; ?>"></div>
        <div class="mb-2"><label class="form-label">Loại giường</label><input name="bed_type" class="form-control" value="<?php echo h($edit['bed_type']); ?>"></div>
        <div class="mb-2"><label class="form-label">Giá/đêm</label><input type="number" step="1000" name="price" class="form-control" value="<?php echo h($edit['price']); ?>"></div>
        <div class="mb-2"><label class="form-label">Địa điểm</label><input name="location" class="form-control" value="<?php echo h($edit['location']); ?>"></div>
        <div class="mb-2"><label class="form-label">Tên khách sạn</label><input name="hotel_name" class="form-control" value="<?php echo h($edit['hotel_name']); ?>"></div>
        <div class="mb-2"><label class="form-label">Địa chỉ khách sạn</label><input name="hotel_address" class="form-control" value="<?php echo h($edit['hotel_address']); ?>"></div>
        <div class="mb-2"><label class="form-label">Mô tả khách sạn</label><textarea name="hotel_description" class="form-control" rows="3"><?php echo h($edit['hotel_description']); ?></textarea></div>
        <div class="mb-2"><label class="form-label">Số phòng còn lại</label><input type="number" name="remaining" class="form-control" value="<?php echo (int)$edit['remaining']; ?>"></div>
        <div class="mb-3"><label class="form-label">Các tuỳ chọn (1 dòng/tuỳ chọn)</label><textarea name="options" class="form-control" rows="4"><?php echo h($edit['options']); ?></textarea></div>
        <div class="mb-3">
          <label class="form-label">Ảnh phòng (chọn nhiều)</label>
          <input type="file" name="images[]" multiple class="form-control">
          <?php if(!empty($room_images)): ?>
            <div class="row mt-2">
              <?php foreach($room_images as $img): ?>
                <div class="col-4 mb-2 text-center">
                  <img src="<?php echo h($img['image_url']); ?>" style="max-width:100%; height:120px; object-fit:cover; border-radius:6px;">
                  <div><a href="?action=delimg&id=<?php echo $id; ?>&img=<?php echo $img['id']; ?>" class="btn btn-sm btn-outline-danger mt-1" onclick="return confirm('Xóa ảnh này?')">Xóa</a></div>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
        <button class="btn btn-primary"><?php echo $action==='edit' ? 'Cập nhật' : 'Tạo mới'; ?></button>
      </form>
    </div></div>
  </div>
  <div class="col-md-8">
    <table class="table table-striped align-middle">
      <thead><tr><th>#</th><th>Tên phòng</th><th>Tour</th><th>Giá</th><th>Còn</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($rooms as $r): ?>
          <tr>
            <td><?php echo (int)$r['id']; ?></td>
            <td><?php echo h($r['name']); ?></td>
            <td><?php echo h($tours[$r['tour_id']] ?? ('#'.$r['tour_id'])); ?></td>
            <td><?php echo money($r['price']); ?></td>
            <td><?php echo (int)$r['remaining']; ?></td>
            <td class="text-end">
              <a class="btn btn-sm btn-outline-primary" href="?action=edit&id=<?php echo (int)$r['id']; ?>">Sửa</a>
              <a class="btn btn-sm btn-outline-danger" href="?action=delete&id=<?php echo (int)$r['id']; ?>" onclick="return confirm('Xóa phòng này?')">Xóa</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
