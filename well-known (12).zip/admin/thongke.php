<?php
require_once __DIR__ . '/../config.php';
require_admin();

$payment = $_GET['payment'] ?? '';
$start   = $_GET['start'] ?? '';
$end     = $_GET['end'] ?? '';

$sql = "SELECT DATE(created_at) as ngay, COUNT(*) as total_orders, SUM(total_price) as total_money
        FROM bookings WHERE 1";
$params = [];

if ($payment && in_array($payment, ['MOMO','VNPAY','TIEN_MAT'])) {
    $sql .= " AND payment_method = ?";
    $params[] = $payment;
}
if ($start) {
    $sql .= " AND DATE(created_at) >= ?";
    $params[] = $start;
}
if ($end) {
    $sql .= " AND DATE(created_at) <= ?";
    $params[] = $end;
}

$sql .= " GROUP BY DATE(created_at) ORDER BY ngay ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Chuẩn bị dữ liệu cho chart
$labels = [];
$orders = [];
$money  = [];
$total_orders_all = 0;
$total_money_all  = 0;

foreach ($data as $row) {
    $labels[] = $row['ngay'];
    $orders[] = $row['total_orders'];
    $money[]  = $row['total_money'];
    $total_orders_all += $row['total_orders'];
    $total_money_all  += $row['total_money'];
}
?>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ADMIN</title>
  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

  <style>
    body {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
  
  
  </style>
</head>
<body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container">
      <a class="navbar-brand fw-bold" href="#">
        <i class="fas fa-home me-2"></i>Admin
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="mainNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link active" href="index.php">Trang chủ</a></li>
        </ul>
      </div>
    </div>
  </nav>
  <br>
  <br>
<h3> Thống kê đặt tour</h3>

<form method="get" class="row g-2 mb-3">
  <div class="col-auto">
    <label class="form-label">Phương thức</label>
    <select name="payment" class="form-select">
      <option value="">-- Tất cả --</option>
      <option value="MOMO"  <?php if($payment==='MOMO') echo 'selected'; ?>>MOMO</option>
      <option value="VNPAY" <?php if($payment==='VNPAY') echo 'selected'; ?>>VNPAY</option>
      <option value="TIEN_MAT" <?php if($payment==='TIEN_MAT') echo 'selected'; ?>>Tiền mặt</option>
    </select>
  </div>
  <div class="col-auto">
    <label class="form-label">Từ ngày</label>
    <input type="date" name="start" value="<?php echo h($start); ?>" class="form-control">
  </div>
  <div class="col-auto">
    <label class="form-label">Đến ngày</label>
    <input type="date" name="end" value="<?php echo h($end); ?>" class="form-control">
  </div>
  <div class="col-auto align-self-end">
    <button class="btn btn-primary">Lọc</button>
  </div>
</form>

<div class="row mb-4">
  <div class="col-md-6">
    <div class="card shadow-sm">
      <div class="card-body">
        <h5 class="card-title">Tổng số booking</h5>
        <div class="fs-4 fw-bold text-primary"><?php echo $total_orders_all; ?></div>
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card shadow-sm">
      <div class="card-body">
        <h5 class="card-title">Tổng doanh thu</h5>
        <div class="fs-4 fw-bold text-success"><?php echo money($total_money_all); ?></div>
      </div>
    </div>
  </div>
</div>

<canvas id="chart" height="120"></canvas>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('chart').getContext('2d');
const chart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($labels); ?>,
        datasets: [
            {
                label: 'Số đơn đặt',
                data: <?php echo json_encode($orders); ?>,
                borderColor: 'blue',
                backgroundColor: 'rgba(0,123,255,0.2)',
                yAxisID: 'y'
            },
            {
                label: 'Doanh thu',
                data: <?php echo json_encode($money); ?>,
                borderColor: 'green',
                backgroundColor: 'rgba(40,167,69,0.2)',
                yAxisID: 'y1'
            }
        ]
    },
    options: {
        responsive: true,
        interaction: {
            mode: 'index',
            intersect: false,
        },
        stacked: false,
        scales: {
            y: {
                type: 'linear',
                display: true,
                position: 'left',
                ticks: { precision: 0 }
            },
            y1: {
                type: 'linear',
                display: true,
                position: 'right',
                grid: { drawOnChartArea: false },
                ticks: { callback: value => new Intl.NumberFormat('vi-VN').format(value) + ' đ' }
            }
        }
    }
});
</script>
