<?php require_once __DIR__ . '/../config.php'; require_admin();
$action = $_GET['action'] ?? '';
$id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD']==='POST' && $action==='edit' && $id) {
  $fullname = post('fullname'); $email = post('email'); $phone = post('phone'); $role = post('role');
  $pwd = post('password');
  $params = [$fullname,$email,$phone,$role,$id];
  $sql = "UPDATE users SET fullname=?, email=?, phone=?, role=?";
  if ($pwd) { $hash = password_hash($pwd, PASSWORD_BCRYPT); $sql .= ", password_hash=". $pdo->quote($hash); }
  $sql .= " WHERE id=?";
  $pdo->prepare($sql)->execute($params);
  flash('ok','Cập nhật user thành công'); header("Location: users.php"); exit;
}
if ($action==='delete' && $id) {
  $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
  flash('ok','Đã xóa user'); header("Location: users.php"); exit;
}

$users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ADMIN</title>
  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

  <style>
    body {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
  
  
  </style>
</head>
<body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container">
      <a class="navbar-brand fw-bold" href="#">
        <i class="fas fa-home me-2"></i>Admin
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="mainNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link active" href="index.php">Trang chủ</a></li>
        </ul>
      </div>
    </div>
  </nav>
  
<h3>User members</h3>
<?php if ($m=flash('ok')): ?><div class="alert alert-success"><?php echo h($m); ?></div><?php endif; ?>
<table class="table table-striped align-middle">
  <thead><tr><th>#</th><th>Họ tên</th><th>Username</th><th>Phone</th><th>Role</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($users as $u): ?>
    <tr>
      <td><?php echo (int)$u['id']; ?></td>
      <td><?php echo h($u['fullname']); ?><div class="small text-muted"><?php echo h($u['email']); ?></div></td>
      <td><?php echo h($u['username']); ?></td>
      <td><?php echo h($u['phone']); ?></td>
      <td><?php echo h($u['role']); ?></td>
      <td class="text-end">
        <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#edit<?php echo (int)$u['id']; ?>">Sửa</button>
        <?php if ((int)$u['id'] !== (int)current_user()['id']): ?>
          <a class="btn btn-sm btn-outline-danger" href="?action=delete&id=<?php echo (int)$u['id']; ?>" onclick="return confirm('Xóa user này?')">Xóa</a>
        <?php endif; ?>
      </td>
    </tr>
    <div class="modal fade" id="edit<?php echo (int)$u['id']; ?>">
      <div class="modal-dialog"><div class="modal-content">
        <form method="post" action="?action=edit&id=<?php echo (int)$u['id']; ?>">
          <div class="modal-header"><h5 class="modal-title">Sửa user</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
          <div class="modal-body">
            <div class="mb-2"><label class="form-label">Họ tên</label><input name="fullname" class="form-control" value="<?php echo h($u['fullname']); ?>"></div>
            <div class="mb-2"><label class="form-label">Email</label><input name="email" class="form-control" value="<?php echo h($u['email']); ?>"></div>
            <div class="mb-2"><label class="form-label">SĐT</label><input name="phone" class="form-control" value="<?php echo h($u['phone']); ?>"></div>
            <div class="mb-2"><label class="form-label">Mật khẩu (để trống nếu không đổi)</label><input name="password" type="password" class="form-control"></div>
            <div class="mb-2"><label class="form-label">Role</label>
              <select name="role" class="form-select">
                <?php foreach (['member','admin'] as $r): ?><option <?php if($u['role']===$r) echo 'selected'; ?>><?php echo $r; ?></option><?php endforeach; ?>
              </select>
            </div>
          </div>
          <div class="modal-footer"><button class="btn btn-primary">Lưu</button></div>
        </form>
      </div></div>
    </div>
  <?php endforeach; ?>
  </tbody>
</table>
