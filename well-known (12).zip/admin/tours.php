<?php require_once __DIR__ . '/../config.php'; require_admin();

$action = $_GET['action'] ?? '';
$id = (int)($_GET['id'] ?? 0);
if ($_SERVER['REQUEST_METHOD']==='POST' && ($action==='create' || $action==='edit')) {
  $imagePath = '';
  if (!empty($_FILES['image']['name'])) {
    $uploadDir = __DIR__ . '/../uploads/';
    if (!is_dir($uploadDir)) {
      mkdir($uploadDir, 0777, true);
    }
    $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
    $filename = uniqid('tour_') . '.' . $ext;
    $targetFile = $uploadDir . $filename;

    if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
      $imagePath = 'uploads/' . $filename; // lưu relative path
    }
  }

  if ($action==='edit' && empty($imagePath)) {
    $st = $pdo->prepare("SELECT image_url FROM tours WHERE id=?");
    $st->execute([$id]);
    $old = $st->fetch(PDO::FETCH_ASSOC);
    $imagePath = $old['image_url'] ?? '';
  }

  $data = [
    'code' => post('code'),
    'name' => post('name'),
    'departure' => post('departure'),
    'start_date' => post('start_date'),
    'end_date' => post('end_date'),
    'duration_days' => (int)post('duration_days'),
    'destination' => post('destination'),
    'tour_type' => post('tour_type'),
    'transport' => post('transport'),
    'status' => post('status'),
    'price' => (float)post('price'),
    'image_url' => $imagePath,
    'description' => $_POST['description'] ?? '',
    'itinerary' => $_POST['itinerary'] ?? '',
  ];

  if ($action==='create') {
    $sql = "INSERT INTO tours(code,name,departure,start_date,end_date,duration_days,destination,tour_type,transport,status,price,image_url,description,itinerary)
            VALUES(:code,:name,:departure,:start_date,:end_date,:duration_days,:destination,:tour_type,:transport,:status,:price,:image_url,:description,:itinerary)";
  } else {
    $data['id'] = $id;
    $sql = "UPDATE tours SET code=:code,name=:name,departure=:departure,start_date=:start_date,end_date=:end_date,duration_days=:duration_days,
            destination=:destination,tour_type=:tour_type,transport=:transport,status=:status,price=:price,image_url=:image_url,
            description=:description,itinerary=:itinerary WHERE id=:id";
  }
  $stmt = $pdo->prepare($sql);
  $stmt->execute($data);
  flash('ok','Lưu tour thành công');
  header("Location: tours.php"); exit;
}

if ($action==='delete' && $id) {
  $pdo->prepare("DELETE FROM tours WHERE id=?")->execute([$id]);
  flash('ok','Đã xóa tour'); header("Location: tours.php"); exit;
}

$tours = $pdo->query("SELECT * FROM tours ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ADMIN</title>
  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

  <style>
    body {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
  
  
  </style>
</head>
<body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container">
      <a class="navbar-brand fw-bold" href="#">
        <i class="fas fa-home me-2"></i>Admin
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="mainNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link active" href="index.php">Trang chủ</a></li>
        </ul>
      </div>
    </div>
  </nav>
  
<h3>Quản lý tour</h3>


<?php if ($m=flash('ok')): ?><div class="alert alert-success"><?php echo h($m); ?></div><?php endif; ?>
<div class="row">
  <div class="col-md-4">
    <div class="card"><div class="card-body">
      <h5><?php echo $action==='edit' ? 'Sửa tour' : 'Tạo tour'; ?></h5>
      <?php 
      $edit = ['code'=>'','name'=>'','departure'=>'','start_date'=>'','end_date'=>'','duration_days'=>3,'destination'=>'','tour_type'=>'','transport'=>'','status'=>'Còn chỗ','price'=>0,'image_url'=>'','description'=>'','itinerary'=>'']; 
      if ($action==='edit' && $id) { 
        $st=$pdo->prepare("SELECT * FROM tours WHERE id=?"); 
        $st->execute([$id]); 
        $edit=$st->fetch(PDO::FETCH_ASSOC); 
      } 
      ?>
      <form method="post" enctype="multipart/form-data" action="?action=<?php echo $action==='edit'?'edit':'create'; ?><?php if($id) echo '&id='.$id; ?>">
        <div class="mb-2"><label class="form-label">Mã tour</label><input name="code" class="form-control" required value="<?php echo h($edit['code']); ?>"></div>
        <div class="mb-2"><label class="form-label">Tên tour</label><input name="name" class="form-control" required value="<?php echo h($edit['name']); ?>"></div>
        <div class="mb-2"><label class="form-label">Nơi khởi hành</label><input name="departure" class="form-control" required value="<?php echo h($edit['departure']); ?>"></div>
        <div class="row">
          <div class="col-6 mb-2"><label class="form-label">Ngày đi</label><input type="date" name="start_date" class="form-control" required value="<?php echo h($edit['start_date']); ?>"></div>
          <div class="col-6 mb-2"><label class="form-label">Ngày về</label><input type="date" name="end_date" class="form-control" required value="<?php echo h($edit['end_date']); ?>"></div>
        </div>
        <div class="mb-2"><label class="form-label">Thời gian (ngày)</label><input type="number" name="duration_days" class="form-control" value="<?php echo (int)$edit['duration_days']; ?>"></div>
        <div class="mb-2"><label class="form-label">Điểm đến</label><input name="destination" class="form-control" required value="<?php echo h($edit['destination']); ?>"></div>
        <div class="mb-2"><label class="form-label">Loại hình tour</label><input name="tour_type" class="form-control" value="<?php echo h($edit['tour_type']); ?>"></div>
        <div class="mb-2"><label class="form-label">Phương tiện</label><input name="transport" class="form-control" value="<?php echo h($edit['transport']); ?>"></div>
        <div class="mb-2"><label class="form-label">Trạng thái</label>
          <select name="status" class="form-select">
            <?php foreach (['Còn chỗ','Hết chỗ','Sắp khởi hành'] as $st): ?>
              <option <?php if(($edit['status']??'')===$st) echo 'selected'; ?>><?php echo $st; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-2"><label class="form-label">Giá tour</label><input type="number" step="1000" name="price" class="form-control" value="<?php echo h($edit['price']); ?>"></div>
        <div class="mb-2">
          <label class="form-label">Ảnh tour</label>
          <input type="file" name="image" class="form-control">
          <?php if (!empty($edit['image_url'])): ?>
            <div class="mt-2"><img src="<?php echo h($edit['image_url']); ?>" alt="tour" style="max-width:100%; height:auto; border-radius:6px;"></div>
          <?php endif; ?>
        </div>
        <div class="mb-2">
          <label class="form-label">Mô tả tour (CKEditor)</label>
          <textarea id="description" name="description" class="form-control"><?php echo h($edit['description']); ?></textarea>
        </div>
        <div class="mb-2">
          <label class="form-label">Lộ trình tour (CKEditor)</label>
          <textarea id="itinerary" name="itinerary" class="form-control"><?php echo h($edit['itinerary']); ?></textarea>
        </div>
        <button class="btn btn-primary"><?php echo $action==='edit' ? 'Cập nhật' : 'Tạo mới'; ?></button>
      </form>

      <!-- Nhúng CKEditor -->
      <script src="https://cdn.ckeditor.com/4.22.1/standard/ckeditor.js"></script>
      <script>
        CKEDITOR.replace('description');
        CKEDITOR.replace('itinerary');
      </script>
    </div></div>
  </div>
  <div class="col-md-8">
    <div class="d-flex justify-content-between align-items-center">
      <h5>Danh sách tour</h5>
      <a class="btn btn-outline-secondary btn-sm" href="rooms.php">Quản lý phòng</a>
    </div>
    <table class="table table-striped align-middle">
      <thead><tr><th>#</th><th>Tên</th><th>Giá</th><th>Ngày</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($tours as $t): ?>
        <tr>
          <td><?php echo (int)$t['id']; ?></td>
          <td><?php echo h($t['name']); ?><div class="small text-muted"><?php echo h($t['code']); ?></div></td>
          <td><?php echo money($t['price']); ?></td>
          <td class="small"><?php echo h($t['start_date']); ?> → <?php echo h($t['end_date']); ?></td>
          <td class="text-end">
            <a class="btn btn-sm btn-outline-primary" href="?action=edit&id=<?php echo (int)$t['id']; ?>">Sửa</a>
            <a class="btn btn-sm btn-outline-danger" href="?action=delete&id=<?php echo (int)$t['id']; ?>" onclick="return confirm('Xóa tour này?')">Xóa</a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
