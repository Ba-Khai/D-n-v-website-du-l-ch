<?php require_once __DIR__ . '/../config.php';
require_admin();

$totalTours = (int) $pdo->query("SELECT COUNT(*) FROM tours")->fetchColumn();
$pending = (int) $pdo->query("SELECT COUNT(*) FROM bookings WHERE status='pending'")->fetchColumn();
$today = date('Y-m-d');
$yesterday = date('Y-m-d', strtotime('-1 day'));
$monthStart = date('Y-m-01');
$todayCount = (int) $pdo->query("SELECT COUNT(*) FROM bookings WHERE DATE(created_at)='$today'")->fetchColumn();
$yesterdayCount = (int) $pdo->query("SELECT COUNT(*) FROM bookings WHERE DATE(created_at)='$yesterday'")->fetchColumn();
$monthCount = (int) $pdo->query("SELECT COUNT(*) FROM bookings WHERE DATE(created_at) >= '$monthStart'")->fetchColumn();
?>
<html lang="vi">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ADMIN</title>
  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

  <style>
    body {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
  </style>
</head>

<body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container">
      <a class="navbar-brand fw-bold" href="#">
        <i class="fas fa-home me-2"></i>Admin
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="mainNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link active" href="index.php">Trang chủ</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <h3>Trang quản trị</h3>
  <div class="row g-3">
    <div class="col-md-3">
      <div class="card shadow-sm">
        <div class="card-body">
          <div class="small">Tổng tour</div>
          <div class="fs-3 fw-bold"><?php echo $totalTours; ?></div>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card shadow-sm">
        <div class="card-body">
          <div class="small">ĐK tour chờ duyệt</div>
          <div class="fs-3 fw-bold"><?php echo $pending; ?></div>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card shadow-sm">
        <div class="card-body">
          <div class="small">ĐK hôm nay</div>
          <div class="fs-3 fw-bold"><?php echo $todayCount; ?></div>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card shadow-sm">
        <div class="card-body">
          <div class="small">ĐK tháng này</div>
          <div class="fs-3 fw-bold"><?php echo $monthCount; ?></div>
        </div>
      </div>
    </div>
  </div>
  <div class="mt-4 d-flex gap-2">
    <a class="btn btn-primary" href="thongke.php">Thống kê</a>

    <a class="btn btn-outline-secondary" href="tours.php">Tạo tour / phòng</a>
    <a class="btn btn-outline-secondary" href="bookings.php">Duyệt đăng ký</a>
    <a class="btn btn-outline-secondary" href="users.php">User Members</a>
  </div>