<?php 
require_once __DIR__ . '/../config.php'; 
require_admin();

$action = $_GET['action'] ?? '';
$id     = (int)($_GET['id'] ?? 0);
$status_filter = $_GET['status'] ?? '';
$search = trim($_GET['search'] ?? '');
if ($action && $id) {
  if ($action==='approve') {
    $pdo->prepare("UPDATE bookings SET status='approved' WHERE id=?")->execute([$id]);
  } elseif ($action==='decline') {
    $pdo->prepare("UPDATE bookings SET status='declined' WHERE id=?")->execute([$id]);
  } elseif ($action==='cancel') {
    $pdo->prepare("UPDATE bookings SET status='declined' WHERE id=?")->execute([$id]);
  }
  header("Location: bookings.php"); 
  exit;
}

$sql = "SELECT b.*, u.fullname as user_fullname, t.name as tour_name, r.name as room_name
        FROM bookings b 
        JOIN users u ON u.id=b.user_id
        JOIN tours t ON t.id=b.tour_id
        JOIN rooms r ON r.id=b.room_id
        WHERE 1";

/* ====== Thêm filter ====== */
$params = [];
if ($status_filter && in_array($status_filter,['pending','approved','declined'])) {
  $sql .= " AND b.status=?";
  $params[] = $status_filter;
}
if ($search) {
  $sql .= " AND (b.customer_name LIKE ? OR b.phone LIKE ?)";
  $params[] = "%$search%";
  $params[] = "%$search%";
}

$sql .= " ORDER BY b.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ADMIN</title>
  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

  <style>
    body {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
  
  
  </style>
</head>
<body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container">
      <a class="navbar-brand fw-bold" href="#">
        <i class="fas fa-home me-2"></i>Admin
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="mainNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link active" href="index.php">Trang chủ</a></li>
        </ul>
      </div>
    </div>
  </nav>
  
<h3>Đăng ký tour</h3>

<!-- Form tìm kiếm và lọc -->
<form method="get" class="row g-2 mb-3">
  <div class="col-auto">
    <input type="text" name="search" value="<?php echo h($search); ?>" class="form-control" placeholder="Tìm theo tên hoặc SĐT">
  </div>
  <div class="col-auto">
    <select name="status" class="form-select">
      <option value="">-- Tất cả --</option>
      <option value="pending"  <?php if($status_filter==='pending') echo 'selected'; ?>>Chờ duyệt</option>
      <option value="approved" <?php if($status_filter==='approved') echo 'selected'; ?>>Đã duyệt</option>
      <option value="declined" <?php if($status_filter==='declined') echo 'selected'; ?>>Bị từ chối</option>
    </select>
  </div>
  <div class="col-auto">
    <button class="btn btn-primary">Lọc</button>
  </div>
</form>

<table class="table table-striped align-middle">
  <thead>
    <tr>
      <th>#</th>
      <th>Khách</th>
      <th>Tour</th>
      <th>Phòng</th>
      <th>Thanh toán</th>
      <th>Tổng</th>
      <th>Trạng thái</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($rows as $b): ?>
      <tr>
        <td><?php echo (int)$b['id']; ?></td>
        <td>
          <?php echo h($b['customer_name']); ?>
          <div class="small text-muted"><?php echo h($b['phone']); ?></div>
        </td>
        <td><?php echo h($b['tour_name']); ?></td>
        <td><?php echo h($b['room_name']); ?></td>
        <td><?php echo h($b['payment_method']); ?></td>
        <td><?php echo money($b['total_price']); ?></td>
        <td>
          <span class="badge <?php 
            echo $b['status']==='approved'?'bg-success':
                 ($b['status']==='declined'?'bg-danger':'bg-secondary'); ?>">
            <?php echo h($b['status']); ?>
          </span>
        </td>
        <td class="text-end">
          <!-- Nút xem ghi chú -->
          <?php if ($b['note']): ?>
            <button type="button" class="btn btn-sm btn-info" 
              onclick="alert('Ghi chú: <?php echo h($b['note']); ?>')">
              Xem ghi chú
            </button>
          <?php endif; ?>

          <!-- Nút xử lý trạng thái -->
          <?php if ($b['status']==='pending'): ?>
            <a class="btn btn-sm btn-outline-success" href="?action=approve&id=<?php echo (int)$b['id']; ?>">Duyệt</a>
            <a class="btn btn-sm btn-outline-danger" href="?action=decline&id=<?php echo (int)$b['id']; ?>">Từ chối</a>
          <?php elseif ($b['status']==='approved'): ?>
            <a class="btn btn-sm btn-outline-warning" href="?action=cancel&id=<?php echo (int)$b['id']; ?>">Hủy</a>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; if (!$rows): ?>
      <tr><td colspan="8" class="text-center">Chưa có đăng ký</td></tr>
    <?php endif; ?>
  </tbody>
</table>
