<?php
require_once __DIR__ . '/header.php';
require_login();

$tid = (int) ($_GET['tour_id'] ?? 0);
$rid = (int) ($_GET['room_id'] ?? 0);

$t = $pdo->prepare("SELECT * FROM tours WHERE id=?");
$t->execute([$tid]);
$t = $t->fetch(PDO::FETCH_ASSOC);

$r = $pdo->prepare("SELECT * FROM rooms WHERE id=? AND tour_id=?");
$r->execute([$rid, $tid]);
$r = $r->fetch(PDO::FETCH_ASSOC);

if (!$t || !$r) {
    echo '<div class="alert alert-danger">Dữ liệu không hợp lệ.</div>';
    require 'footer.php';
    exit;
}

$total = (float) $t['price'] + (float) $r['price'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name   = $_POST['customer_name'];
    $phone  = $_POST['phone'];
    $note   = $_POST['note'] ?? '';
    $method = $_POST['payment_method'];

    // Insert booking
    $stmt = $pdo->prepare("INSERT INTO bookings 
        (tour_id, room_id, customer_name, phone, note, payment_method, total_price, status, user_id, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, NOW())");
    $stmt->execute([
        $tid, $rid, $name, $phone, $note, $method, $total, $_SESSION['user']['id']
    ]);
    $bookingId = $pdo->lastInsertId();

    if ($method === 'VNPAY') {
        // Chuyển sang trang thanh toán VNPAY
        header("Location: vnpay_checkout.php?id=" . $bookingId);
        exit;
    } elseif ($method === 'MOMO') {
        // Chuyển sang trang thanh toán MOMO
        header("Location: momo_checkout.php?id=" . $bookingId);
        exit;
    } else {
        // Thanh toán tiền mặt -> ra hóa đơn
        header("Location: hoadon.php?id=" . $bookingId);
        exit;
    }
}
?>

<div class="container py-4">
  <h3>Thanh toán tour</h3>
  <div class="row g-3">

    <div class="col-md-7">
      <div class="card">
        <div class="card-body">
          <h5 class="mb-3">Thông tin khách hàng</h5>

          <form method="post">
            <div class="mb-2">
              <label class="form-label">Họ và tên</label>
              <input type="text" name="customer_name" class="form-control" required>
            </div>

            <div class="mb-2">
              <label class="form-label">Số điện thoại</label>
              <input type="number" name="phone" class="form-control" required>
            </div>

            <div class="mb-2">
              <label class="form-label">Ghi chú</label>
              <textarea name="note" rows="3" class="form-control"></textarea>
            </div>

            <div class="mb-3">
              <label class="form-label">Phương thức thanh toán</label>
              <select name="payment_method" class="form-select" required>
                <option value="MOMO">MOMO</option>
                <option value="VNPAY">VNPAY</option>
                <option value="TIEN_MAT">Thanh toán trực tiếp</option>
              </select>
            </div>

            <div class="d-flex justify-content-between align-items-center">
              <div class="fw-bold fs-5">Tổng thanh toán: <?php echo money($total); ?></div>
              <button type="submit" class="btn btn-success">Đặt phòng</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <div class="col-md-5">
      <div class="card">
        <div class="card-body">
          <h5 class="mb-3">Thông tin tour</h5>

          <p><strong>Tên tour:</strong> <?php echo h($t['name']); ?></p>
          <p><strong>Mã tour:</strong> <?php echo h($t['code']); ?></p>
          <p><strong>Nơi khởi hành:</strong> <?php echo h($t['departure']); ?></p>
          <p><strong>Ngày khởi hành:</strong> <?php echo h($t['start_date']); ?></p>
          <p><strong>Ngày về:</strong> <?php echo h($t['end_date']); ?></p>
          <p><strong>Giá tour:</strong> <?php echo money($t['price']); ?></p>

          <hr>

          <h6>Phòng đã chọn</h6>
          <p><strong><?php echo h($r['name']); ?></strong> - <?php echo money($r['price']); ?>/đêm</p>
          <p>KS: <?php echo h($r['hotel_name']); ?> (<?php echo h($r['location']); ?>)</p>
          <p>Còn: <?php echo (int) $r['remaining']; ?> • Tối đa: <?php echo (int) $r['max_guests']; ?></p>
        </div>
      </div>
    </div>

  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
