 <?php require_once __DIR__ . '/header.php'; 
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $username = post('username');
  $password = post('password');
  $stmt = $pdo->prepare("SELECT * FROM users WHERE username=?");
  $stmt->execute([$username]);
  $u = $stmt->fetch(PDO::FETCH_ASSOC);
  if ($u && password_verify($password, $u['password_hash'])) {
    $_SESSION['user'] = $u;
    header("Location: index.php"); exit;
  } else {
    flash('err', 'Sai thông tin đăng nhập');
  }
}
?><!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BKQ Travel Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/8d9be25307.js" crossorigin="anonymous"></script>
    <style>
/* Header */
.header{
    background-color: #fff;
    padding: 10px 30px;
}

.header .inner-wrap{
    display: flex;
    align-items: center;
    justify-content: space-between;
    
}

.header .inner-logo img{
    height: 60px;
    width: auto;
}

.header .inner-menu > ul{
    display: flex;
    padding: 0;
    margin: 0;
    gap: 29px;
}

.header .inner-menu > ul > li{
    position: relative;
}

.header .inner-menu > ul > li > a{
    color: #000000;
    font-size: 16px;
    font-weight: 700;
    text-transform: uppercase;
}

.header .inner-menu > ul > li > a.active,
.header .inner-menu > ul > li > a:hover{
    color: #6ac9c9;
}

.header .inner-button{
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.header .contact-button{
    padding: 15px 15px;
    border-radius: 30px;
    background-color: #6ac9c9;
    font-size: 16px;
    font-weight: 700;
    border: none;
    text-transform: uppercase;
}

.header .account-button{
    margin-left: 15px;
    width: 30px;
    height: 30px;
    border-radius: 100%;
    background-color: var(--color-primary);
    border: none;
}

.header .account-button img{
    height: 25px;
    width: auto;
    margin: 0 auto;
}
/* End Header */





        *{
    margin: 0;
    padding: 0;
    list-style: none;
    /*bo dau cham cua li*/
}

        body {
            background: url('https://s3-alpha-sig.figma.com/img/2023/89f2/7fcb3015752657498c4a85e565c03524?Expires=1742169600&Key-Pair-Id=APKAQ4GOSFWCW27IBOMQ&Signature=AA9HCivoomwUOVOUrVQNSp9jjBJJVfCz3HyHF1es-ILF4sx0mphE5xtgWrxm6rFyC2buzFNUarTAEg8oxygr0z7SqTrnzGGh~uPGlHxAGYdWUWztNyYYHZa3LgwvDe1YeRfQAtJ-Axv8zqRzJkhfwYpuwYyZMFAUqnjBmEt1YupyCAVV4pfRhkWfnyxWLsAMsS6Fu58NDMNsjgWNaBtbfENeSDa1DNhLK4GdR3jpga~JGO9glOaR0LXcXFwlIs~-2ANunHOsfopN8G1gMYsGKNvSDelKajLfFx5JiZsNegH0npCy6QRAy609Oij5vvWEMysTPNllaYxTxfC2jRYTPw__') no-repeat center center/cover;
            height: 950px;
        }
        a{
            text-decoration: none;
        }
        .login-container {
            background: white;
            padding: 20px;
            border-radius: 30px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            max-width: 566px;
            margin-top:89px;
            height: 749px;
        }
        .btn-custom {
            background-color: #6ac9c9;  
            color: white;
            border-radius:20px;
            margin-right: 30px;
            margin-left: 20px;
            margin-top: 48px;
        }
        .btn-light {
            background-color: #d9d9d9;
            color: black;
            border-radius:20px;
            margin-top: 48px;
            margin-right: 48px;
        }
        
        .label{
            float:left;
            color:black;
            text-decoration: none; 
                
        }
      
         .btn-custom2 {
            background-color: #6ac9c9;
            width: 470px !important;
            border-radius:20px;
            margin-right: 20px;
            margin-left: 20px;
            margin-top: 48px;
            
        }



        .footer{
    background-color: #7DD1D1;
    margin-top: 180px;
}

.footer-connect{
    display: flex;
    justify-content: space-between;
}

.title-footer{
    color: #000000;
    font-weight: 600;
    font-size: 25px;
    margin-bottom: 16px;
}

.address-footer{
    margin-bottom: 16px;
}

.entire-info-website .address-footer p{
    color: #000000;
}

.footer-menu-section .list-unstyled{
    padding-left: 0;
}

.footer-menu-section ul > li{
    margin-bottom: 16px;

}

.footer-menu-section > ul > li > a{
    color: #000000;
}

.footer-copyright{
    background: #000;
    color: #fff;
    padding: 10px 0;
    text-align: center;
}

        
    </style>
</head>
<body>
   

    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="login-container text-center">
            <div class="d-flex justify-content-between">
                <button class="btn btn-custom" style="width: 227px;height:40px;">Login</button>
<button class="btn btn-light" style="width:227px;height:40px;" 
        onclick="window.location.href='register.php'">
  Sign up
</button>
            </div> 
                <?php if ($m=flash('err')): ?><div class="alert alert-danger"><?php echo h($m); ?></div><?php endif; ?>

    <form method="post"  class="mt3">
                <div class="mb-3">
                    <a class="label "style="margin-left: 20px; margin-top:83px">Tên đăng nhập</a>
                    <input type="username" class="form-control" style="margin-left: 20px; width: 470px;"placeholder="Input your email address" name="username" >
                </div>
                <div class="mb-3" style="position: relative;width: 470px; margin-left: 20px;">
                    <a class="label">Mật Khẩu</a>
                    <input name="password" type="password" class="form-control" style="padding-right: 40px; width: 100%;margin-right: 40px;" placeholder="Input your password">
                    <i id="togglePassword" class="fa-solid fa-eye-slash " style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); color: #bababa; cursor: pointer;margin-top: 12px;"></i>
                </div>
            
                <div class="d-flex justify-content-between">
                    <div>
                        <input type="checkbox" id="remember"style="margin-left: 20px;"> <label for="remember">Remember me</label>
                    </div>
                    <a href="#" class="text-decoration-none" style="color: #008b8b; margin-right: 40px;">Forgot password?</a>
                </div>
                
                <div style="position: relative; width: 470px; ">
                    <i class="fa-solid fa-right-to-bracket" style="position: absolute; left: 220px; top: 50%; transform: translateY(-50%);margin-top: 9px;"></i>
                    <button  class="btn btn-custom2 w-100 mt-3 text-dark" style="padding-left: 40px;">Login</button>
                </div>
            </form>
            <hr>
            <div >
            <a href="#" class="text-decoration-none " style="color: black;">Or continue with</a>
            <div style="position: relative; width: 470px; ">
                <i class="fa-brands fa-google" style="position: absolute; left: 180px; top: 50%; transform: translateY(-50%);margin-top: 9px;"></i>
                <button type="submit" class="btn btn-custom2 w-100 mt-3 text-dark" style="padding-left: 40px;">Login with Google</button>
            </div>
            <div style="position: relative; width: 470px; ">
                <i class="fa-brands fa-facebook" style="position: absolute; left: 180px; top: 50%; transform: translateY(-50%);margin-top: 9px;"></i>
                <button type="submit" class="btn btn-custom2 w-100 mt-3 text-dark" style="padding-left: 60px;">Login with Facebook</button>
            </div>
            
            </div>
            
        </div>
    </div>
    <footer class="footer"> 
        <div class="container">
          <div class="footer-connect">
            <div class="entire-info-website">
              <div class="title-footer">
                 Liên hệ</div>
              <div class="address-footer"> 
                <p> <b>CÔNG TY CỔ PHẦN DU LỊCH BKQ</b></p>
                <p>
                   SỐ 01, Đ.QUANG TRUNG, P.HẢI CHÂU 1, Q.HẢI CHÂU, TP.ĐÀ NẴNG.</p>
                <p>
                   HotLine: 091234524</p>
                <p>
                   Email: info@BKQ.com</p>
                <p>
                   Mã số doanh nghiệp: 0110376372 do Sở Kế hoạch và Đầu tư Thành phố Hà Nội cấp ngày 05/06/2023</p>
              </div>
            </div>
            <div class="footer-menu-section">
              <div class="title-footer">BKQ.com </div>
              <ul class="list-unstyled">
                <li> <a href="#">Giới thiệu</a></li>
                <li> <a href="#">Về chúng tôi </a></li>
                <li> <a href="#">Blog</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="footer-copyright"> 
          <div class="container">
             Copyright 2022 BKQ.com - All Rights Reserved</div>
        </div>
      </footer>
  
</body>
</html>
