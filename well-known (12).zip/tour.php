<?php require_once __DIR__ . '/header.php'; 
$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM tours WHERE id=?");
$stmt->execute([$id]);
$t = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$t) { echo '<div class="alert alert-danger">Tour không tồn tại.</div>'; require 'footer.php'; exit; }

$rooms = $pdo->prepare("SELECT * FROM rooms WHERE tour_id=? ORDER BY price ASC");
$rooms->execute([$id]);
$rs = $rooms->fetchAll(PDO::FETCH_ASSOC);

$reviews = $pdo->prepare("SELECT r.*, u.fullname 
                          FROM reviews r 
                          JOIN users u ON u.id=r.user_id 
                          WHERE r.tour_id=? 
                          ORDER BY r.created_at DESC");
$reviews->execute([$id]);
$review_list = $reviews->fetchAll(PDO::FETCH_ASSOC);
?>

<link rel="stylesheet" href="assets/css/layout.css" />
<link rel="stylesheet" href="assets/css/thong-tin-tour.css" />

<section id="section-hero">
  <div class="container">
    <h2><?php echo h($t['name']); ?></h2>
  </div>
</section>

<div class="container my-4">
  <div class="row g-4">
    <!-- Thông tin tour -->
    <div class="col-lg-8">
      <div class="card shadow-sm border-0 rounded-3">
        <?php if (!empty($t['image_url'])): ?>
          <img src="<?php echo h($t['image_url']); ?>" class="card-img-top rounded-top" alt="tour">
        <?php endif; ?>
        <div class="card-body p-4">
          <h3 class="card-title mb-2"><?php echo h($t['name']); ?></h3>
          <div class="text-muted small mb-3">
            <span class="me-2"><i class="fa-solid fa-hashtag"></i> <?php echo h($t['code']); ?></span>
            <span class="me-2"><i class="fa-solid fa-map-location-dot"></i> <?php echo h($t['tour_type']); ?></span>
            <span><i class="fa-solid fa-bus"></i> <?php echo h($t['transport']); ?></span>
          </div>

          <div class="row mb-3">
            <div class="col-md-6">
              <p><strong><i class="fa-regular fa-clock"></i> Thời gian:</strong> <?php echo h($t['duration_days']); ?> ngày (<?php echo h($t['start_date']); ?> → <?php echo h($t['end_date']); ?>)</p>
              <p><strong><i class="fa-solid fa-location-dot"></i> Điểm đến:</strong> <?php echo h($t['destination']); ?></p>
              <p><strong><i class="fa-solid fa-train-subway"></i> Nơi khởi hành:</strong> <?php echo h($t['departure']); ?></p>
              <p><strong><i class="fa-solid fa-thumbtack"></i> Trạng thái:</strong> 
                <span class="badge bg-success"><?php echo h($t['status']); ?></span>
              </p>
            </div>
            <div class="col-md-6">
              <p><strong><i class="fa-solid fa-van-shuttle"></i> Phương tiện:</strong> <?php echo h($t['transport']); ?></p>
              <p><strong><i class="fa-solid fa-sack-dollar"></i> Giá tour:</strong> 
                <span class="text-danger fw-bold"><?php echo money($t['price']); ?></span>
              </p>
            </div>
          </div>

          <hr>
          <h5 class="mb-2"><i class="fa-solid fa-book-open"></i> Mô tả tour</h5>
          <div class="border rounded p-3 bg-light mb-4"><?php echo $t['description']; ?></div>

          <h5 class="mb-2"><i class="fa-solid fa-map"></i> Lộ trình tour</h5>
          <div class="border rounded p-3 bg-light mb-4"><?php echo $t['itinerary']; ?></div>

          <!-- Đánh giá tour -->
          <h5 class="mb-3"><i class="fa-solid fa-star text-warning"></i> Đánh giá tour</h5>
<?php if ($msg = flash('ok')): ?>
  <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
    <i class="fa-solid fa-circle-check"></i> <?php echo $msg; ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
<?php endif; ?>

<?php if ($msg = flash('error')): ?>
  <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
    <i class="fa-solid fa-triangle-exclamation"></i> <?php echo $msg; ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
<?php endif; ?>

          <?php if (is_logged_in()): ?>
            <form method="post" action="review_submit.php" class="mb-4">
              <input type="hidden" name="tour_id" value="<?php echo (int)$t['id']; ?>">
              <div class="mb-2">
                <label class="form-label">Chọn số sao</label>
                <select name="rating" class="form-select" required>
                  <option value="">-- Chọn --</option>
                  <option value="5">★★★★★ - Rất tốt</option>
                  <option value="4">★★★★☆ - Tốt</option>
                  <option value="3">★★★☆☆ - Bình thường</option>
                  <option value="2">★★☆☆☆ - Tệ</option>
                  <option value="1">★☆☆☆☆ - Rất tệ</option>
                </select>
              </div>
              <div class="mb-2">
                <textarea name="comment" class="form-control" rows="3" placeholder="Viết cảm nhận của bạn..." required></textarea>
              </div>
              <button class="btn btn-primary"><i class="fa-solid fa-paper-plane"></i> Gửi đánh giá</button>
            </form>
          <?php else: ?>
            <div class="alert alert-info">Bạn cần <a href="login.php">đăng nhập</a> để viết đánh giá.</div>
          <?php endif; ?>

          <!-- Danh sách đánh giá -->
          <?php if ($review_list): ?>
            <?php foreach ($review_list as $rv): ?>
              <div class="border rounded p-3 mb-3 bg-light">
                <div class="d-flex justify-content-between">
                  <strong><?php echo h($rv['fullname']); ?></strong>
                  <small class="text-muted"><?php echo h($rv['created_at']); ?></small>
                </div>
                <div class="text-warning mb-1">
                  <?php echo str_repeat("★", (int)$rv['rating']); ?>
                  <?php echo str_repeat("☆", 5 - (int)$rv['rating']); ?>
                </div>
                <div><?php echo nl2br(h($rv['comment'])); ?></div>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <div class="alert alert-secondary">Chưa có đánh giá nào.</div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Phòng -->
    <div class="col-lg-4">
      <div class="card shadow-sm border-0 rounded-3">
        <div class="card-body p-4">
          <h5 class="card-title mb-3"><i class="fa-solid fa-hotel"></i> Phòng của tour</h5>
          <?php foreach ($rs as $r): ?>
            <div class="border rounded p-3 mb-3 bg-light">
              <div class="fw-bold text-primary">
                <?php echo h($r['name']); ?> • <?php echo money($r['price']); ?>/đêm
              </div>
              <div class="small text-muted">
                Còn lại: <b><?php echo (int)$r['remaining']; ?></b> • 
                Tối đa: <?php echo (int)$r['max_guests']; ?> khách
              </div>
              <a class="btn btn-primary btn-sm w-100 mt-2" 
                 href="<?php echo asset_url('rooms.php?tour_id='.(int)$t['id'].'&room_id='.(int)$r['id']); ?>">
                <i class="fa-solid fa-door-open"></i> Chọn phòng
              </a>
            </div>
          <?php endforeach; if (!$rs): ?>
            <div class="alert alert-info">Chưa có phòng cho tour này.</div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
