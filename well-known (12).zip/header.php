<?php require_once __DIR__ . '/config.php'; ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
<link rel="stylesheet" href="assets/css/style.css?ver=<?php echo time(); ?>">
<header class="header">
  <div class="inner-wrap">
    <?php if (!empty($settings['logo_url'])): ?>
      <div class="inner-logo"> <a href="#"><img src="<?php echo h($settings['logo_url']); ?>" alt=""></a></div>
    <?php endif; ?>

    <nav class="inner-menu">
      <ul>
        <li><a class="active" href="/index.php">Trang chủ</a></li>
        <li><a href="/gioithieu.php">Giới thiệu</a></li>
        <li><a href="/tour.php">Tìm tour</a></li>
        <li><a href="/rooms.php">Tìm khách sạn</a></li>
        <li><a href=" https://www.ivivu.com/blog">Blog</a></li>

        <li><a href="https://zalo.me/0901234567" target="_blank">Tư vấn</a></li>

        <li><a href="tel:0372648522">Hotline: 0901234524</a></li>

        <?php if (is_admin()): ?>
          <li class="nav-item"><a class="nav-link" href="<?php echo asset_url('admin/index.php'); ?>">Admin</a></li>
        <?php endif; ?>
      </ul>
    </nav>

    <div class="inner-button">
      <div class="contact-button"><a href="#">Liên hệ với chúng tôi</a></div>
      <ul class="navbar-nav ms-auto align-items-center">
        <?php if (is_logged_in()):
          $u = current_user(); ?>
          <li class="nav-item me-3">
            <span class="fw-semibold text-black">
              👋 Xin chào, <span class="text-warning"><?php echo h($u['fullname']); ?></span>
            </span>
          </li>
          <li class="nav-item">
            <a class="btn btn-sm btn-info-light rounded-pill px-3" href="<?php echo asset_url('logout.php'); ?>">
              <i class="fas fa-sign-out-alt me-1"></i> Đăng xuất
            </a>
          </li>
        <?php else: ?>
          <li class="nav-item me-2">
            <a class="btn btn-sm btn-info-light rounded-pill px-3" href="<?php echo asset_url('login.php'); ?>">
              <i class="fas fa-sign-in-alt me-1"></i> Đăng nhập
            </a>
          </li>
          <li class="nav-item">
            <a class="btn btn-sm btn-warning rounded-pill px-3 fw-semibold"
              href="<?php echo asset_url('register.php'); ?>">
              <i class="fas fa-user-plus me-1"></i> Đăng ký
            </a>
          </li>
        <?php endif; ?>
      </ul>

    </div>
  </div>
</header>