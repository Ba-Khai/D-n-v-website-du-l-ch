<?php
require 'config.php';
$status = 'failed';
if (isset($_GET['resultCode']) && $_GET['resultCode'] == '0') {
    $status = 'paid';
}

$orderId = $_GET['orderId'] ?? '';
$amount = $_GET['amount'] ?? 0;

if ($status === 'paid' && $orderId) {
    $stmt = $pdo->prepare("UPDATE bookings SET status='paid' WHERE id=?");
    $stmt->execute([$orderId]);
    $msg = "Thanh toán MOMO thành công!";
} else {
    $msg = "Thanh toán MOMO thất bại!";
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Kết quả thanh toán MOMO</title></head>
<body>
<h2><?php echo $msg; ?></h2>
<a href="hoadon.php?id=<?php echo $orderId; ?>">Xem hóa đơn</a>
</body>
</html>
