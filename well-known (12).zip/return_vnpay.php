<?php
require 'config.php';

$vnp_SecureHash = $_GET['vnp_SecureHash'] ?? '';
$inputData = [];
foreach ($_GET as $key => $value) {
    if (substr($key, 0, 4) == "vnp_") {
        $inputData[$key] = $value;
    }
}
unset($inputData['vnp_SecureHash']);
ksort($inputData);

$hashData = urldecode(http_build_query($inputData));
$secureHash = hash_hmac('sha512', $hashData, VNPAY_HASH_SECRET);

// Kiểm tra chữ ký
if ($secureHash === $vnp_SecureHash) {
    if ($_GET['vnp_ResponseCode'] == '00') {
        $status = 'paid';
        $msg = "Thanh toán VNPAY thành công!";
        // Lấy booking_id đã gắn trong vnp_TxnRef
        $bookingId = $_GET['vnp_TxnRef'];
        $stmt = $pdo->prepare("UPDATE bookings SET status='paid' WHERE id=?");
        $stmt->execute([$bookingId]);
    } else {
        $msg = "Thanh toán VNPAY thất bại!";
    }
} else {
    $msg = "Sai chữ ký VNPAY!";
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Kết quả thanh toán VNPAY</title></head>
<body>
<h2><?php echo $msg; ?></h2>
<a href="hoadon.php?id=<?php echo $orderId; ?>">Xem hóa đơn</a>
</body>
</html>
