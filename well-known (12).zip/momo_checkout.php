<?php
require 'config.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    die("Thiếu booking id");
}

$stmt = $pdo->prepare("SELECT * FROM bookings WHERE id=?");
$stmt->execute([$id]);
$booking = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$booking) {
    die("Không tìm thấy booking");
}

$endpoint = "https://test-payment.momo.vn/v2/gateway/api/create"; // endpoint test, khi live đổi link
$partnerCode = MOMO_PARTNER_CODE;
$accessKey   = MOMO_ACCESS_KEY;
$secretKey   = MOMO_SECRET_KEY;

$orderId = $booking['id'];
$requestId = time() . "";
$orderInfo = "Thanh toán tour #" . $booking['id'];
$amount = (string)intval($booking['total_price']);
$redirectUrl = BASE_URL . "return_momo.php";
$ipnUrl = BASE_URL . "notify_momo.php";
$extraData = "";

$requestType = "captureWallet";

$rawHash = "accessKey=" . $accessKey .
    "&amount=" . $amount .
    "&extraData=" . $extraData .
    "&ipnUrl=" . $ipnUrl .
    "&orderId=" . $orderId .
    "&orderInfo=" . $orderInfo .
    "&partnerCode=" . $partnerCode .
    "&redirectUrl=" . $redirectUrl .
    "&requestId=" . $requestId .
    "&requestType=" . $requestType;

$signature = hash_hmac("sha256", $rawHash, $secretKey);

$data = [
    'partnerCode' => $partnerCode,
    'partnerName' => "MoMo Test",
    'storeId'     => "MoMoStore",
    'requestId'   => $requestId,
    'amount'      => $amount,
    'orderId'     => $orderId,
    'orderInfo'   => $orderInfo,
    'redirectUrl' => $redirectUrl,
    'ipnUrl'      => $ipnUrl,
    'lang'        => 'vi',
    'extraData'   => $extraData,
    'requestType' => $requestType,
    'signature'   => $signature
];

$ch = curl_init($endpoint);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Content-Length: ' . strlen(json_encode($data))
]);
$result = curl_exec($ch);
curl_close($ch);

$response = json_decode($result, true);

if (isset($response['payUrl'])) {
    header("Location: " . $response['payUrl']);
    exit;
} else {
    echo "<h3>Không tạo được thanh toán MOMO</h3>";
    echo "<pre>";
    print_r($response);
    echo "</pre>";
}
